<?php
	include('connect.php');

if(isset($_POST['reg'])){
	$firstname=$_POST['firstname'];
	$secondname=$_POST['secondname'];
	$lastname=$_POST['lastname'];
	$phone=$_POST['phone'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	$spkey=$_POST['spkey'];
	
	
$insert="INSERT INTO admin (firstname,secondname,lastname,phone,username,password,spkey) VALUES('$firstname','$secondname','$lastname','$phone','$username','$password','$spkey')";

$run=mysqli_query($dbconnect,$insert);
		//check if it has saved
		if($run){ 
  echo "<script> alert('Data stored successfully'); </script>" ;
  header("location: dashboard.php");
}
else{
  echo "<script>alert('Error storing the Data ');</script>" ;
  header("location: error.html");
}

}

?>