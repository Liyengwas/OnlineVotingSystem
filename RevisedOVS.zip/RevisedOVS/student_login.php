<?php
//initialize sessions
	session_start();

//login code 
include('connect.php');

if(isset($_POST['login'])){
	
$username = $_POST['username'];
$password = $_POST['password'];
$spkey=$_POST['spkey'];

	
//sql statement

$checkuser = "SELECT * FROM students WHERE username='$username' AND password='$password' AND spkey = '$spkey'" ;
	

//run the sql statement

$checkuserrun = mysqli_query($dbconnect,$checkuser );

//loop to get the values 
	
	if(mysqli_num_rows($checkuserrun)){
		
	echo("<script>window.open('dashboard1.php','_self')</script>");
	$_SESSION['username'] = $username;
	
		
	}
	
	else{ 

  echo "<script>alert('Error logging in to your acoount ');</script>" ;
  header("location: index.php");

	 
 
	} // end of else
	
} //end of isset if
	  
?>