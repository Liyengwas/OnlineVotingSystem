<?php
	include('connect.php');

if(isset($_POST['submit'])){
	$TeamName=$_POST['TeamName'];
	$chairperson=$_POST['chairperson'];
	$vicechair=$_POST['vicechair'];
	$secgen=$_POST['secgen'];
	$treasurer=$_POST['treasurer'];
	$sawrep=$_POST['sawrep'];
	$isrep=$_POST['isrep'];
    $sneeds=$_POST['sneeds'];
	
	
$insert="INSERT INTO candidates (TeamName,chairperson,vicechair,secgen,treasurer,sawrep,isrep,sneeds) VALUES('$TeamName','$chairperson','$vicechair','$secgen','$treasurer','$sawrep','$isrep','$sneeds')";

$run=mysqli_query($dbconnect,$insert);
		//check if it has saved
		if($run){ 
  echo "<script> alert('Data stored successfully'); </script>" ;
  header("location: dashboard1.php");
}
else{
  echo "<script>alert('Error storing the Data ');</script>" ;
  header("location: error.html");
}

}

?>