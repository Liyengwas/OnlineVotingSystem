<?php

$host = "localhost";
$user = "root";
$pass = "";
$db = "RevisedOVS";

$dbconnect= mysqli_connect($host, $user, $pass, $db);

if(!$dbconnect){

  echo "<script>alert('Error connecting to the db');</script>" . mysqli_error($dbconnect);
}


?>