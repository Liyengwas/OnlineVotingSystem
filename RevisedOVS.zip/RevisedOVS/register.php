<!doctype html>
<html lang="en">
  <head>
	<!-- Required meta tags -->
		<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

		<!-- Bootstrap CSS -->
			<link rel="stylesheet" href="css/bootstrap.min.css">
      <link rel="stylesheet" href="css/style.css">
       <link href="https://fonts.googleapis.com/css?family=Playfair+Display" rel="stylesheet">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/css/bootstrap.min.css" integrity="sha384-PDle/QlgIONtM1aqA2Qemk5gPOE7wFq8+Em+G/hmo5Iq0CCmYZLv3fVRDJ4MMwEA" crossorigin="anonymous">

		<title>OnlineVotingSystem</title>
	</head>
<body style="font-family: 'Playfair Display', serif; background-color: #0000;">
   <!--start of the body-->

   <!--navbar-->
   <nav class="navbar navbar-expand-lg navbar-light bg-light">
     <a class="navbar-brand" href="index.php">OnlineVotingSystem</a>
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
       <span class="navbar-toggler-icon"></span>
     </button>
     <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
       <div class="navbar-nav">
         <a class="nav-item nav-link active" href="index.php">Student's Login<span class="sr-only">(current)</span></a>
         <a class="nav-item nav-link" href="admin.php">Admin's Login</a>
         <a class="nav-item nav-link" href="contact.php">Contact Us</a>
       </div>
     </div>
   </nav>
   <!--end navbar-->

   <div class="container" id="container" style="margin-top:100px;">
      <div class="row">
        <div class="card offset-3 col-6 offset-3">
            <form method="post" action="student_reg.php">
              <br><h1 style="font-family: 'Playfair Display', serif;">Register For Your Student's Account</h1><br>
                <input type="text" class="form-control" placeholder="Firstname" name="firstname" required>
                <br>
                <input type="text" class="form-control" placeholder="Secondname" name="secondname" required>
                <br>
                <input type="text" class="form-control" placeholder="Lastname" name="lastname" required>
                <br>
                <input type="text" class="form-control" placeholder="Phone Number" name="phone" required>
                <br>
                <input type="text" class="form-control" placeholder="Registration Number" name="username" required>
                <br>
                <input type="password" class="form-control" placeholder="Password" name="password" required>
                <br>
                <input type="text" class="form-control" placeholder="Special Key" name="spkey">
                <br>
                  <input type="submit" class="btn btn-outline-success" value="Submit" name="reg">
                  <input type="reset" class="btn btn-outline-danger" value="Reset">
                  <br><br>
                      <p>Already Have An Account? <a href="index.php" class="btn btn-outline-primary">Login</a></p>
                  <br>
            </form>

        </div><!--end card-->
      </div>

   </div>

<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.min.js"></script>
    <script src="js/jquery1.9.min.js">
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.0/js/bootstrap.min.js" integrity="sha384-7aThvCh9TypR7fIc2HV4O/nFMVCBwyIUKL8XCtKE+8xgCgl/PQGuFsvShjr74PBp" crossorigin="anonymous"></script>

</body><!--end body-->
</html>
